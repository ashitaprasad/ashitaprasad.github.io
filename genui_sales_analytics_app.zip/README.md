# GenUI Sales Analytics App

A generative-UI sales analytics dashboard built with Flutter, Riverpod, and the [GenUI SDK](https://pub.dev/packages/genui).

The app demonstrates the full A2UI (Agent-to-User Interface) protocol: a Gemini model streams JSONL surface-update events that are decoded by the GenUI SDK into live, native Flutter widgets — no layout code written by the developer.

## Features

- **JSONL streaming** — every token the model produces is forwarded immediately via `A2uiTransportAdapter.addChunk()`, so UI surfaces appear incrementally.
- **Tool calling** — the model calls `get_sales_data` to fetch regional KPI figures before composing the analytics dashboard.
- **Two surfaces**
  - `input_form` — ChoicePicker × 3 (states, KPI, year), a period selector, and a Submit button; rendered automatically by the model on startup.
  - `analytics_dashboard` — MetricCard, DonutChart, BarChart, and TabularData widgets populated with real query results.
- **Custom catalog items** (all backed by JSON Schema):
  - `MetricCard` — headline KPI value with colour-coded trend indicator.
  - `DonutChart` — `CustomPainter` ring chart with a legend.
  - `BarChart` — stacked-row bar chart with a shared colour palette.
  - `TabularData` — scrollable `DataTable` with a tinted heading row.
- **Surface-driven PageView navigation** — each surface maps to a page; dot indicators animate between them.

## Project Structure

```
lib/
├── api_key/          # Platform-conditional API key retrieval (IO + web)
├── data/
│   └── mock_sales_repository.dart   # Raw data constants + fetchSalesData()
├── tools/
│   └── sales_data_tool.dart         # Gemini tool declaration + handleGetSalesData()
├── utils/
│   └── generative_ai_transport.dart # Transport: streaming + multi-round tool loop
├── domain/
│   ├── sales_session.dart           # ChatSession ChangeNotifier
│   └── sales_session_provider.dart  # Riverpod Provider<ChatSession>
├── presentation/
│   ├── catalogs/
│   │   ├── sales_catalog.dart       # Catalog assembly (pruned BasicCatalogItems + custom)
│   │   └── items/                   # MetricCard, DonutChart, BarChart, TabularData
│   └── chat/
│       └── chat_screen.dart         # Root screen with PageView + progress indicator
└── main.dart
```

## Getting Started

### Prerequisites

- Flutter SDK ≥ 3.11.5
- A [Gemini API key](https://aistudio.google.com/app/apikey)

### Run

Pass your API key at build time with `--dart-define`:

```bash
flutter run -d macos --dart-define=GEMINI_API_KEY=YOUR_KEY_HERE
```

The app auto-sends a `Start` message on launch; the model renders the input form immediately without any user interaction.

### Interact

After the input form appears, select states, a KPI, a year, and a period, then tap **Submit**. The model fetches data via the `get_sales_data` tool and streams an analytics dashboard surface.

You can also send free-form follow-up messages, e.g.:

- "Compare Karnataka and Tamil Nadu by Profit for 2023."
- "Show me the quarterly breakdown as a table."

## Architecture Notes

- **Transport** (`GenerativeAiTransport`) implements the GenUI `Transport` interface. It runs a multi-round loop: stream all parts → forward `TextPart` chunks immediately → collect `FunctionCall` parts → execute tool → append `functionResponse` → continue until a round produces no function calls.
- **Catalog** starts from `BasicCatalogItems.asCatalog()`, removes items irrelevant to analytics, and adds the four domain-specific items.
- **Riverpod** uses a plain `Provider<ChatSession>` (Riverpod 3 compatible) with `ref.onDispose` for cleanup and `ListenableBuilder` in the widget tree for rebuilds.
- **Data / Tools split** — `data/` holds pure Dart data logic with no Gemini dependency; `tools/` holds the Gemini schema declaration and a thin bridge to the data layer.

import 'dart:async';

import 'package:genui/genui.dart';
import 'package:google_generative_ai/google_generative_ai.dart' as genai;
import 'package:logging/logging.dart';

import '../tools/sales_data_tool.dart';

/// A [Transport] implementation that wraps the Google Generative AI SDK.
///
/// Demonstrates two key A2UI concepts working together:
///
/// **JSONL Streaming**: The model's final text response is consumed via
/// [genai.GenerativeModel.generateContentStream].  Each chunk is forwarded
/// directly to [A2uiTransportAdapter.addChunk], which parses the incremental
/// JSONL and notifies [SurfaceController] to build widget tree updates in
/// real time — surfaces appear and update as tokens stream in.
///
/// **Tool Calling**: Before producing the final UI, the model may invoke the
/// `get_sales_data` tool.  Tool-call rounds use blocking [generateContentStream]
/// too; the adapter only receives text, never function-call parts, so there
/// is no conflict.  The loop runs for up to [_maxRounds] turns.
///
/// The system instruction and tool declarations are injected at model
/// construction time — the canonical approach for the google_generative_ai SDK.
final class GenerativeAiTransport implements Transport {
  GenerativeAiTransport({
    required String apiKey,
    required String systemInstruction,
    required void Function(Object error, StackTrace? stack) onError,
  }) : _onError = onError,
       _adapter = A2uiTransportAdapter(),
       _model = genai.GenerativeModel(
         model: 'gemini-flash-latest',
         apiKey: apiKey,
         systemInstruction: genai.Content.system(systemInstruction),
         tools: [salesDataTool],
       );

  static const int _maxRounds = 24;

  final A2uiTransportAdapter _adapter;
  final genai.GenerativeModel _model;
  final List<genai.Content> _chat = [];
  final void Function(Object error, StackTrace? stack) _onError;
  final Logger _logger = Logger('GenerativeAiTransport');

  @override
  Stream<A2uiMessage> get incomingMessages => _adapter.incomingMessages;

  @override
  Stream<String> get incomingText => _adapter.incomingText;

  static String _extractUserText(ChatMessage message) {
    final buffer = StringBuffer();
    for (final part in message.parts) {
      if (part.isUiInteractionPart) {
        buffer.write(part.asUiInteractionPart!.interaction);
      } else if (part is TextPart) {
        buffer.write(part.text);
      }
    }
    return buffer.toString();
  }

  @override
  Future<void> sendRequest(ChatMessage message) async {
    final userText = _extractUserText(message);
    if (userText.isEmpty) return;

    _chat.add(genai.Content('user', [genai.TextPart(userText)]));

    // Tool-calling + streaming loop.
    //
    // Every round uses generateContentStream so that:
    //  - text chunks are forwarded immediately to the A2UI adapter (JSONL
    //    streaming — surfaces build incrementally as tokens arrive).
    //  - function-call parts are collected without blocking; no text is
    //    emitted in rounds where the model decides to call a tool.
    for (var round = 0; round < _maxRounds; round++) {
      final calls = <genai.FunctionCall>[];
      final allParts = <genai.Part>[];

      try {
        final stream = _model.generateContentStream(_chat);
        await for (final response in stream) {
          final candidate = response.candidates.firstOrNull;
          if (candidate == null) continue;

          for (final part in candidate.content.parts) {
            allParts.add(part);
            switch (part) {
              case genai.FunctionCall():
                // Collect tool invocations — do not stream anything yet.
                calls.add(part);
              case genai.TextPart(:final text) when text.isNotEmpty:
                // Stream each text chunk straight to the A2UI adapter.
                // The adapter parses JSONL incrementally: surfaces and
                // components appear in the Flutter UI as tokens arrive.
                _adapter.addChunk(text);
            }
          }
        }
      } catch (e, st) {
        _onError(e, st);
        rethrow;
      }

      // Append this model turn to the chat history.
      _chat.add(genai.Content('model', allParts));

      if (calls.isEmpty) {
        // No tool calls — the streamed text was the final A2UI response. Done.
        break;
      }

      // Execute tool calls and append function responses for the next round.
      for (final call in calls) {
        if (call.name != 'get_sales_data') {
          _logger.warning('Unknown tool requested: ${call.name}');
          _chat.add(
            genai.Content.functionResponse(
              call.name,
              {'error': 'Unknown tool: ${call.name}'},
            ),
          );
          continue;
        }
        try {
          _logger.info('Tool call: ${call.name} args=${call.args}');
          final result = await handleGetSalesData(
            Map<String, Object?>.from(call.args),
          );
          _chat.add(genai.Content.functionResponse(call.name, result));
        } catch (e, st) {
          _logger.warning('Tool ${call.name} failed', e, st);
          _chat.add(
            genai.Content.functionResponse(call.name, {'error': '$e'}),
          );
        }
      }
      // Loop back for the next model turn with the tool results.
    }
  }

  @override
  void dispose() {
    _adapter.dispose();
  }
}


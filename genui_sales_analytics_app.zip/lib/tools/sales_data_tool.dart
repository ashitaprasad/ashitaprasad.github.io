import 'package:google_generative_ai/google_generative_ai.dart' as genai;

import '../data/mock_sales_repository.dart';

// ---------------------------------------------------------------------------
// Gemini tool declaration
// ---------------------------------------------------------------------------

/// The [genai.Tool] passed to [genai.GenerativeModel] at construction time.
///
/// Registers `get_sales_data` so the LLM can request sales analytics data
/// after the user submits the input form.
final salesDataTool = genai.Tool(
  functionDeclarations: [
    genai.FunctionDeclaration(
      'get_sales_data',
      'Fetches sales analytics data for the selected Indian states. '
      'Call this after the user submits the analytics input form.',
      genai.Schema.object(
        properties: {
          'states': genai.Schema.array(
            items: genai.Schema.string(
              description: 'Indian state name.',
            ),
            description: 'States selected by the user.',
          ),
          'kpi': genai.Schema.string(
            description:
                'Sales KPI to analyze. One of: Revenue, Profit, Volume, CAC, LTV.',
          ),
          'year': genai.Schema.integer(
            description: 'The year for the data (e.g. 2024).',
          ),
          'period': genai.Schema.string(
            description:
                'Time-period granularity. One of: quarterly, monthly.',
          ),
        },
        requiredProperties: ['states', 'kpi', 'year', 'period'],
      ),
    ),
  ],
);

// ---------------------------------------------------------------------------
// Tool handler — called when the LLM invokes get_sales_data
// ---------------------------------------------------------------------------

/// Parses the raw [args] map from a Gemini [FunctionCall] and delegates to
/// [fetchSalesData] in the data layer.
Future<Map<String, Object?>> handleGetSalesData(
  Map<String, Object?> args,
) {
  return fetchSalesData(
    states: (args['states'] as List<Object?>).cast<String>(),
    kpi: args['kpi'] as String,
    year: (args['year'] as int?) ?? 2024,
    period: (args['period'] as String?) ?? 'quarterly',
  );
}


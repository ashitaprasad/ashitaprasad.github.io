import 'package:genui/src/model/client_function.dart';
import 'package:json_schema_builder/json_schema_builder.dart';

import 'sales_data_tool.dart';

/// A GenUI [ClientFunction] that exposes `get_sales_data` as a client-side
/// callable from within UI JSON data bindings (e.g. `{call: get_sales_data}`).
///
/// When the model generates a data binding like:
/// ```json
/// { "call": "get_sales_data", "args": { "states": [...], "kpi": "Revenue", ... } }
/// ```
/// the GenUI runtime resolves it by calling [execute], which delegates to the
/// same [handleGetSalesData] used by the Gemini tool-call path.
class GetSalesDataClientFunction implements ClientFunction {
  const GetSalesDataClientFunction();

  @override
  String get name => 'get_sales_data';

  @override
  String get description =>
      'Fetches sales analytics data for the selected Indian states. '
      'Provide states (list), kpi (string), year (int), and period (string).';

  @override
  ClientFunctionReturnType get returnType => ClientFunctionReturnType.object;

  @override
  Schema get argumentSchema => Schema.object(
        properties: {
          'states': Schema.list(
            items: Schema.string(description: 'Indian state name.'),
            description: 'States selected by the user.',
          ),
          'kpi': Schema.string(
            description:
                'Sales KPI to analyze. One of: Revenue, Profit, Volume, CAC, LTV.',
          ),
          'year': Schema.integer(
            description: 'The year for the data (e.g. 2024).',
          ),
          'period': Schema.string(
            description:
                'Time-period granularity. One of: quarterly, monthly.',
          ),
        },
      );

  @override
  Stream<Object?> execute(Map<String, Object?> args, ExecutionContext context) {
    return Stream.fromFuture(
      handleGetSalesData(args),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:genui/genui.dart';

import '../../domain/sales_session_provider.dart';

/// The root screen for the Sales Analytics app.
///
/// Demonstrates **surface-driven navigation**: the AI controls which "page"
/// the user sees by creating named surfaces via A2UI `createSurface` /
/// `surfaceUpdate` messages.  Each new surface is appended as a page in a
/// [PageView]; the view automatically scrolls to the newest surface.
///
/// A progress bar and floating status chip communicate AI activity to the user.
class ChatScreen extends ConsumerStatefulWidget {
  const ChatScreen({super.key});

  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  final PageController _pageController = PageController();

  /// Tracks which surface IDs are already shown so we can animate to new ones.
  int _lastKnownSurfaceCount = 0;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _animateToLastPage(int surfaceCount) {
    if (surfaceCount > 1) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_pageController.hasClients) {
          _pageController.animateToPage(
            surfaceCount - 1,
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeInOut,
          );
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Read the session once — it is stable for the lifetime of the ProviderScope.
    // ListenableBuilder handles rebuilds whenever the session calls notifyListeners.
    final session = ref.read(chatSessionProvider)!;

    return ListenableBuilder(
      listenable: session,
      builder: (context, _) {
        final surfaces = session.messages
            .where((m) => m.isSurface)
            .map((m) => m.surfaceId!)
            .toList();

        // Animate to the new surface whenever one is added.
        if (surfaces.length > _lastKnownSurfaceCount) {
          _lastKnownSurfaceCount = surfaces.length;
          _animateToLastPage(surfaces.length);
        }

        return Scaffold(
          appBar: AppBar(
            title: const Text('Sales Analytics'),
            centerTitle: false,
            backgroundColor: Theme.of(context).colorScheme.surface,
            surfaceTintColor: Colors.transparent,
            bottom: session.isProcessing
                ? PreferredSize(
                    preferredSize: const Size.fromHeight(3),
                    child: LinearProgressIndicator(
                      backgroundColor: Colors.transparent,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  )
                : null,
            actions: [
              if (surfaces.length > 1)
                _PageIndicator(
                  pageController: _pageController,
                  count: surfaces.length,
                ),
              if (session.errorMessage != null)
                IconButton(
                  icon: const Icon(Icons.key_outlined),
                  tooltip: 'Change API Key',
                  onPressed: () =>
                      ref.read(apiKeyProvider.notifier).setKey(''),
                ),
              const SizedBox(width: 8),
            ],
          ),
          body: surfaces.isEmpty
              ? _LoadingPlaceholder(
                  isProcessing: session.isProcessing,
                  errorMessage: session.errorMessage,
                  onChangeApiKey: session.errorMessage != null
                      ? () => ref.read(apiKeyProvider.notifier).setKey('')
                      : null,
                )
              : PageView.builder(
                  controller: _pageController,
                  itemCount: surfaces.length,
                  itemBuilder: (context, index) {
                    return SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: Surface(
                        surfaceContext: session.surfaceController
                            .contextFor(surfaces[index]),
                      ),
                    );
                  },
                ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Supporting widgets
// ---------------------------------------------------------------------------

/// Animated dot indicators showing the current page in the surface PageView.
class _PageIndicator extends StatefulWidget {
  const _PageIndicator({
    required this.pageController,
    required this.count,
  });

  final PageController pageController;
  final int count;

  @override
  State<_PageIndicator> createState() => _PageIndicatorState();
}

class _PageIndicatorState extends State<_PageIndicator> {
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    widget.pageController.addListener(_onPageChanged);
  }

  void _onPageChanged() {
    final page = widget.pageController.page?.round() ?? 0;
    if (page != _currentPage) {
      setState(() => _currentPage = page);
    }
  }

  @override
  void dispose() {
    widget.pageController.removeListener(_onPageChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 0; i < widget.count; i++)
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: i == _currentPage ? 16 : 8,
            height: 8,
            margin: const EdgeInsets.symmetric(horizontal: 3),
            decoration: BoxDecoration(
              color: i == _currentPage
                  ? color
                  : color.withAlpha(76),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
      ],
    );
  }
}

/// Shown while the AI is generating the first surface.
class _LoadingPlaceholder extends StatelessWidget {
  const _LoadingPlaceholder({
    required this.isProcessing,
    this.errorMessage,
    this.onChangeApiKey,
  });

  final bool isProcessing;
  final String? errorMessage;
  final VoidCallback? onChangeApiKey;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 480),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (isProcessing) ...[
                const CircularProgressIndicator(),
                const SizedBox(height: 24),
                Text(
                  'Building your analytics form…',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: Colors.grey.shade600,
                  ),
                ),
              ] else if (errorMessage != null) ...[
                Icon(Icons.error_outline, size: 64, color: colorScheme.error),
                const SizedBox(height: 16),
                Text(
                  'Something went wrong',
                  style: theme.textTheme.titleLarge?.copyWith(
                    color: colorScheme.error,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: colorScheme.errorContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    errorMessage!,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: colorScheme.onErrorContainer,
                      fontFamily: 'monospace',
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                if (onChangeApiKey != null) ...[
                  const SizedBox(height: 24),
                  FilledButton.icon(
                    onPressed: onChangeApiKey,
                    icon: const Icon(Icons.key_outlined),
                    label: const Text('Change API Key'),
                  ),
                ],
              ] else ...[
                Icon(Icons.analytics_outlined, size: 64, color: Colors.grey.shade400),
                const SizedBox(height: 16),
                Text(
                  'Sales Analytics',
                  style: theme.textTheme.titleLarge,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}


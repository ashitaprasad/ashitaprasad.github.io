import 'package:genui/genui.dart';

import '../../tools/get_sales_data_client_function.dart';
import 'items/chart_items.dart';
import 'items/metric_card_item.dart';
import 'items/tabular_data_item.dart';

/// Builds the catalog for the Sales Analytics app.
///
/// Keeps only the [BasicCatalogItems] needed for the input form (Button,
/// ChoicePicker, Column, Row, Text, TextField) and adds four custom
/// analytics widgets.  All other built-in items are removed so the LLM
/// cannot use them, keeping the system prompt compact and focused.
Catalog buildSalesCatalog() {
  return BasicCatalogItems.asCatalog(
    systemPromptFragments: [
      'Use ChoicePicker for all selection inputs (multi-select and single-select).',
      'Use TextField for free-text input such as the year field.',
      'Use a Row with two Buttons as the form submit actions: "Visualize" (for charts) and "View data" (for tabular data).',
      'Arrange form fields vertically using Column.',
    ],
  )
      .copyWithout(
        itemsToRemove: [
          // Remove built-in items that are not needed for this app.
          BasicCatalogItems.audioPlayer,
          BasicCatalogItems.card,
          BasicCatalogItems.checkBox,
          BasicCatalogItems.dateTimeInput,
          BasicCatalogItems.divider,
          BasicCatalogItems.icon,
          BasicCatalogItems.image,
          BasicCatalogItems.list,
          BasicCatalogItems.modal,
          BasicCatalogItems.slider,
          BasicCatalogItems.tabs,
          BasicCatalogItems.video,
        ],
      )
      .copyWith(
        catalogId: 'sales_analytics_catalog',
        newItems: [
          // Custom analytics widgets.
          metricCardItem,
          donutChartItem,
          barChartItem,
          tabularDataItem,
        ],
        newFunctions: [
          const GetSalesDataClientFunction(),
        ],
        systemPromptFragments: [
          'Use MetricCard to highlight a single KPI value with an optional trend.',
          'Use DonutChart to compare KPI values across regions — each slice is one region.',
          'Use BarChart to show KPI values per time period (quarters or months).',
          'Use TabularData for a full breakdown table (regions as rows, periods as columns).',
        ],
      );
}


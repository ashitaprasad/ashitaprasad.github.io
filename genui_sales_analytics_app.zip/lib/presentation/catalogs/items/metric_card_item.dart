import 'package:flutter/material.dart';
import 'package:genui/genui.dart';
import 'package:json_schema_builder/json_schema_builder.dart' as schema;

/// Catalog item for a KPI metric card.
///
/// Displays a headline value, a descriptive title, and an optional trend
/// indicator (e.g. "+12%" in green or "-3%" in red).
final metricCardItem = CatalogItem(
  name: 'MetricCard',
  dataSchema: schema.Schema.object(
    description:
        'A card displaying a single KPI metric with title, value, and '
        'optional trend indicator.',
    properties: {
      'title': schema.Schema.string(description: 'Label for the metric.'),
      'value': schema.Schema.string(
        description: 'Formatted metric value (e.g. "₹3,10,000" or "4,100").',
      ),
      'trend': schema.Schema.string(
        description:
            'Optional trend text. Prefix with "+" for positive (shown in '
            'green) or "-" for negative (shown in red). E.g. "+12%".',
      ),
    },
    required: ['title', 'value'],
  ),
  widgetBuilder: (context) {
    final json = context.data as Map<String, Object?>;
    final title = (json['title'] as String?) ?? 'Metric';
    final value = (json['value'] as String?) ?? '—';
    final trend = json['trend'] as String?;

    final trendColor = trend == null
        ? Colors.grey
        : trend.startsWith('+')
            ? Colors.green.shade600
            : Colors.red.shade600;

    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey.shade600,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              value,
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                letterSpacing: -0.5,
              ),
            ),
            if (trend != null) ...[
              const SizedBox(height: 4),
              Row(
                children: [
                  Icon(
                    trend.startsWith('+')
                        ? Icons.trending_up_rounded
                        : Icons.trending_down_rounded,
                    color: trendColor,
                    size: 16,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    trend,
                    style: TextStyle(
                      fontSize: 13,
                      color: trendColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  },
);


import 'package:flutter/material.dart';
import 'package:genui/genui.dart';
import 'package:json_schema_builder/json_schema_builder.dart' as schema;

/// Catalog item for a scrollable data table.
///
/// Renders column headers and rows of string cells.  Wraps in a
/// [SingleChildScrollView] so wide tables scroll horizontally.
final tabularDataItem = CatalogItem(
  name: 'TabularData',
  dataSchema: schema.Schema.object(
    description: 'A scrollable data table with named columns and string rows.',
    properties: {
      'title': schema.Schema.string(description: 'Optional table title.'),
      'columns': schema.Schema.list(
        description: 'Column header labels.',
        items: schema.Schema.string(),
      ),
      'rows': schema.Schema.list(
        description:
            'Table rows. Each row is an array of string cells matching '
            'the column order.',
        items: schema.Schema.list(items: schema.Schema.string()),
      ),
    },
    required: ['columns', 'rows'],
  ),
  widgetBuilder: (context) {
    final json = context.data as Map<String, Object?>;
    final title = json['title'] as String?;
    final columns = (json['columns'] as List<dynamic>).cast<String>();
    final rowsRaw = (json['rows'] as List<dynamic>).cast<List<dynamic>>();
    final rows = rowsRaw.map((r) => r.cast<String>()).toList();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (title != null) ...[
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 12),
            ],
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                headingRowColor: WidgetStateProperty.all(
                  Colors.deepPurple.shade50,
                ),
                columns: columns
                    .map(
                      (c) => DataColumn(
                        label: Text(
                          c,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    )
                    .toList(),
                rows: rows
                    .map(
                      (row) => DataRow(
                        cells: row.map((cell) => DataCell(Text(cell))).toList(),
                      ),
                    )
                    .toList(),
              ),
            ),
          ],
        ),
      ),
    );
  },
);


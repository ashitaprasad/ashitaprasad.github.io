import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../api_key/io_get_api_key.dart'
    if (dart.library.html) '../api_key/web_get_api_key.dart';
import 'sales_session.dart';

export 'sales_session.dart' show ChatSession, ConversationMessage;

/// Notifier that holds the Gemini API key.
///
/// Pre-populated from the environment if available.
class ApiKeyNotifier extends Notifier<String> {
  @override
  String build() => getApiKey();

  void setKey(String key) => state = key;
}

/// Provider for the Gemini API key.
final apiKeyProvider = NotifierProvider<ApiKeyNotifier, String>(ApiKeyNotifier.new);

/// Riverpod provider for the [ChatSession].
///
/// Returns `null` when no API key has been set yet, so the UI can show the
/// API-key entry screen instead of crashing.
final chatSessionProvider = Provider<ChatSession?>((ref) {
  final apiKey = ref.watch(apiKeyProvider);
  if (apiKey.isEmpty) return null;
  final session = ChatSession(apiKey);
  ref.onDispose(session.dispose);
  return session;
});

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:genui/genui.dart' as genui;
import 'package:logging/logging.dart';

import '../presentation/catalogs/sales_catalog.dart';
import '../utils/generative_ai_transport.dart';

/// A message in the conversation — either plain AI text or a GenUI surface.
class ConversationMessage {
  const ConversationMessage.text(this.text) : surfaceId = null;
  const ConversationMessage.surface(this.surfaceId) : text = null;

  final String? text;
  final String? surfaceId;

  bool get isSurface => surfaceId != null;
}

/// Manages a single GenUI conversation session.
///
/// Responsibilities:
/// - Constructs the [Catalog], [PromptBuilder], [GenerativeAiTransport],
///   [SurfaceController], and [Conversation].
/// - Listens to [Conversation.events] and exposes a simplified [messages] list
///   and [isProcessing] flag to the UI.
/// - Automatically sends the opening message so the AI renders the input form.
class ChatSession extends ChangeNotifier {
  ChatSession(this._apiKey) {
    _init();
  }

  final String _apiKey;
  final Logger _logger = Logger('ChatSession');

  late final GenerativeAiTransport _transport;
  late final genui.SurfaceController _surfaceController;
  late final genui.Conversation _conversation;
  StreamSubscription<genui.ConversationEvent>? _eventsSubscription;

  genui.SurfaceHost get surfaceController => _surfaceController;

  bool _isProcessing = false;
  bool get isProcessing => _isProcessing;

  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  final List<ConversationMessage> _messages = [];
  List<ConversationMessage> get messages => List.unmodifiable(_messages);

  void _init() {
    final catalog = buildSalesCatalog();

    final promptBuilder = genui.PromptBuilder.chat(
      catalog: catalog,
      systemPromptFragments: [
        '''
You are a Sales Analytics AI assistant for Indian market.

## Your Role
Help users explore sales performance data by:
1. Presenting an analytics input form to collect their preferences.
2. Calling the `get_sales_data` tool once the form is submitted.
3. Displaying the results on a new analytics dashboard surface.

## Input Form (first surface — id: "input_form")
Use BasicCatalogItems to build the form:
- ChoicePicker (multi-select) — Region: Kerala, Tamil Nadu, Karnataka, Andhra Pradesh, Telangana, Goa
- ChoicePicker (single-select) — KPI: Revenue, Profit, Volume, CAC, LTV
- TextField — Year (default: 2024)
- ChoicePicker (single-select) — Period: Quarterly, Monthly
- A Row containing TWO side-by-side buttons:
  (1) Button labeled "Visualize" — submits the form and requests charts
  (2) Button labeled "View data" — submits the form and requests tabular data

## Visualize Dashboard (surface — id: "analytics_dashboard")
When the user clicks "Visualize", call `get_sales_data` then build a dashboard with custom catalog items arranged vertically in a Column (one below the other):
- MetricCard: headline KPI value (total or average across selected regions)
- DonutChart: compare the KPI value across selected regions
- BarChart: show the KPI trend across the selected time periods

## Data Table (surface — id: "data_table")
When the user clicks "View data", call `get_sales_data` then build a surface with:
- TabularData: full breakdown table (rows = regions, columns = periods)

CRITICAL:
- Use surfaceId "input_form" for the form, "analytics_dashboard" for the charts dashboard, and "data_table" for the tabular view.
- Always create each result on a NEW surface — never update the input_form surface.
- After showing any result surface, offer a Button labeled "New Analysis" that navigates back.
- Any available tools (e.g. for fetching data) are SERVER-SIDE function calls. You MUST invoke them as function calls BEFORE generating any UI JSON. Never reference a tool inside component properties as a data binding (e.g. {call: tool_name}) — that is not supported. Always embed the data returned by a tool as literal values directly in the component JSON.
''',
        genui.PromptFragments.acknowledgeUser(),
        genui.PromptFragments.requireAtLeastOneSubmitElement(
          prefix: genui.PromptBuilder.defaultImportancePrefix,
        ),
        genui.PromptFragments.uiGenerationRestriction(
          prefix: genui.PromptBuilder.defaultImportancePrefix,
        ),
      ],
    );

    final systemPrompt = promptBuilder.systemPromptJoined();

    _transport = GenerativeAiTransport(
      apiKey: _apiKey,
      systemInstruction: systemPrompt,
      onError: (error, stackTrace) {
        _logger.severe('Transport error', error, stackTrace);
      },
    );

    _surfaceController = genui.SurfaceController(catalogs: [catalog]);

    _conversation = genui.Conversation(
      controller: _surfaceController,
      transport: _transport,
    );

    // Keep isProcessing in sync with conversation state.
    _conversation.state.addListener(_onConversationStateChanged);

    // Map GenUI conversation events to our simplified message list.
    _eventsSubscription = _conversation.events.listen(_onConversationEvent);

    // Kick off the conversation so the AI renders the input form immediately.
    Future<void>.microtask(
      () => _conversation.sendRequest(
        genui.ChatMessage.user('Start'),
      ),
    );
  }

  void _onConversationStateChanged() {
    final isWaiting = _conversation.state.value.isWaiting;
    if (_isProcessing != isWaiting) {
      _isProcessing = isWaiting;
      notifyListeners();
    }
  }

  void _onConversationEvent(genui.ConversationEvent event) {
    switch (event) {
      case genui.ConversationSurfaceAdded(:final surfaceId):
        final alreadyAdded = _messages.any((m) => m.surfaceId == surfaceId);
        if (!alreadyAdded) {
          _messages.add(ConversationMessage.surface(surfaceId));
          notifyListeners();
        }

      case genui.ConversationContentReceived(:final text):
        if (text.isEmpty) return;
        if (_messages.isNotEmpty && !_messages.last.isSurface) {
          // Accumulate streamed text into the last text message.
          final updated = _messages.last.text! + text;
          _messages[_messages.length - 1] = ConversationMessage.text(updated);
        } else {
          _messages.add(ConversationMessage.text(text));
        }
        notifyListeners();

      case genui.ConversationError(:final error):
        _logger.severe('Conversation error', error);
        _errorMessage = '$error';
        _messages.add(ConversationMessage.text('Error: $error'));
        notifyListeners();

      case genui.ConversationWaiting():
      case genui.ConversationComponentsUpdated():
      case genui.ConversationSurfaceRemoved():
        break;
    }
  }

  /// Sends a user message to the AI (e.g., follow-up questions).
  void sendMessage(String text) {
    if (text.trim().isEmpty) return;
    _conversation.sendRequest(genui.ChatMessage.user(text));
  }

  @override
  void dispose() {
    _conversation.state.removeListener(_onConversationStateChanged);
    _eventsSubscription?.cancel();
    _transport.dispose();
    super.dispose();
  }
}
